<?php
// created: 2019-05-25 13:53:53
$dictionary["Meeting"]["fields"]["exp_expenses_meetings"] = array (
  'name' => 'exp_expenses_meetings',
  'type' => 'link',
  'relationship' => 'exp_expenses_meetings',
  'source' => 'non-db',
  'module' => 'Exp_Expenses',
  'bean_name' => false,
  'vname' => 'LBL_EXP_EXPENSES_MEETINGS_FROM_MEETINGS_TITLE',
  'id_name' => 'exp_expenses_meetingsmeetings_ida',
  'link-type' => 'many',
  'side' => 'left',
);
