<?php
 // created: 2019-05-25 13:53:53
$layout_defs["Meetings"]["subpanel_setup"]['exp_expenses_meetings'] = array (
  'order' => 100,
  'module' => 'Exp_Expenses',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_EXP_EXPENSES_MEETINGS_FROM_EXP_EXPENSES_TITLE',
  'get_subpanel_data' => 'exp_expenses_meetings',
);
